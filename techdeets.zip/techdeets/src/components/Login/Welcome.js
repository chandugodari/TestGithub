import React, { Component } from 'react'
import SignIn from './SignIn';
import { Button } from '@material-ui/core';
import axios from 'axios';

class Welcome extends Component {

  constructor(props) {
    super(props)

    this.state = {
      email: '',
      fullName: '',
      mobile: '',
      oganization: '',
      pwd: ''

    }
  }
  
  componentDidMount (){
    axios.get('')
  }

  handleEmailChange = (email) => {
    console.log(`email :: ${email}`);
    this.setState({ email: email });
  }
  handleFullnameChange = (fullName) => {
    this.setState({ fullName: fullName });
  }
  handleMobileChange = (mobile) => {
    this.setState({ mobile: mobile });
  }
  handleOrganizationChange = (oganization) => {
    this.setState({ oganization: oganization });
  }
  handlePwd = (pwd) => {
    this.setState({ pwd: pwd })
  }

  handlePwdCnf = (pwdCnf) => {
    this.setState({ pwdCnf: pwdCnf })
  }
  handleSignIn = (event) => {
    event.preventDefault();
    console.log(`Email ${this.state.email}`);
    console.log(this.state.mobile);
    console.log(this.state.oganization);

  }

  render() {
    return (
      <div>
        <form onSubmit={this.handleSignIn}>
          <SignIn
            onEmailChange={this.handleEmailChange}
            onFullNameChange={this.handleFullnameChange}
            onMobileChange={this.handleMobileChange}
            onOrganizationChange={this.handleOrganizationChange}
            onPwd={this.handlePwd}
            onPwdCnf={this.handlePwdCnf}

          />
          <Button
            variant="contained"
            color="primary" 
            type="submit"> Sign up
          </Button>

        </form>

      </div>
    )
  }
}

export default Welcome;
