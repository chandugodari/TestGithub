import React from 'react';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import './Login.css';
import { TextField, Grid, Button } from '@material-ui/core';
import Input from '../../UI/Input/Input';

const handleEmailChange = (event, props) => {
    console.log(event.target.value);
    const value = event.target.value;
    checkValid(value, 'email')
    props.onEmailChange(value);
}

const handleFullNameChange = (event, props) => {
    const fullName = event.target.value;
    props.onFullNameChange(fullName);
}
const handleMobileChange = (event, props) => {
    const mobile = event.target.value;
    props.onMobileChange(mobile);
}
const handleOrganization = (event, props) => {
    const organization = event.target.value;
    props.onOrganizationChange(organization);
}
const handlePwd = (event, props) => {
    const pwd = event.target.value;
    props.onPwd(pwd);

}
const handlePwdCnf = (event, props) => {
    const  pwdCnf = event.target.value;
    props.onPwdCnf(pwdCnf);
}
const checkValid = (value, rules) => {
    let isValid = true;
    if (!rules) {
        return true;
    }
    if (rules == 'required') {
        isValid = value.trim() !== '' && isValid

    }
    if (rules == 'email') {
        const pattern = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/;
        isValid = pattern.test(value) && isValid;
    }
    return isValid;

}
const signIn = (props) => {
    return (
        <>

            <Card className="Card">
                <CardContent>
                    <p>TechDeets</p>
                    <p>Create your account to continue to techdeets</p>
                    
                        <Grid container>
                            <Grid item xs={12} sm={6}>
                                <TextField
                                    id="email"
                                    label="Email"
                                    type="email"
                                    margin="normal"
                                    variant="outlined"
                                    value={props.email}
                                    onChange={(event) => handleEmailChange(event, props)}
                                />

                            </Grid>
                            <Grid item xs={12} sm={6}>
                                <TextField
                                    id="fullname"
                                    label="Full Name"
                                    value={props.fullName}
                                    margin="normal"
                                    variant="outlined"
                                    onChange={(event) => handleFullNameChange(event, props)}
                                />
                            </Grid>

                            <Grid item xs={12} sm={6}>
                                <TextField
                                    id="mobileNumber"
                                    label="Mobile Number"
                                    type="number"
                                    margin="normal"
                                    variant="outlined"
                                    onChange={(event) => handleMobileChange(event, props)}
                                />
                            </Grid>
                            <Grid item xs={12} sm={6}>
                                <TextField
                                    id="organization"
                                    label="Organization"
                                    type="text"
                                    margin="normal"
                                    variant="outlined"
                                    onChange={(event) => handleOrganization(event, props)}
                                />
                            </Grid>

                            <Grid item xs={12} sm={6}>

                                <TextField
                                    id="password"
                                    label="Password"
                                    type="password"
                                    margin="normal"
                                    variant="outlined"
                                    onChange ={(event) => handlePwd(event, props)}
                                />

                            </Grid>
                            <Grid item xs={12} sm={6}>
                                <TextField
                                    id="confirm"
                                    label="Confirm"
                                    type="password"
                                    margin="normal"
                                    variant="outlined"
                                    onChange ={(event) => handlePwdCnf(event, props)}
                                />
                            </Grid>
                        </Grid>
                        
                    

                </CardContent>
            </Card>

        </>
    );
}

export default signIn;