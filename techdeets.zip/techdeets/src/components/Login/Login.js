import React, { Component } from 'react'
import { connect } from 'react-redux'
import * as actions from '../../store/actions/LoginActions'

class Login extends Component {
    constructor(props) {
        super(props)
        this.state = {
            username: '',
            password: ''
        }
    }
    handleInputChange = (event) => {
        const target = event.target;
        const value = target.value;
        const name = target.name;
        event.preventDefault();
        this.setState({
            [name]: value
        })
    }
    onHandleSubmit = (event) => {
        event.preventDefault();
        console.log(this.state.username);
        console.log(this.state.password);
        this.props.handleSubmit(this.state.username, this.state.password);
        setTimeout(()=>{
            console.log(`This is login status ${this.props.login}`);

        }, 1000);
    }
    render() {
        return (
            <div>
            <form>
                <input type="text" name="username" value={this.state.username} onChange={this.handleInputChange} />
                <input type="password" name="password" value={this.state.password} onChange={this.handleInputChange} />
                <button type="submit" 
                onClick={this.onHandleSubmit}>Submit</button>
            </form>
              
            </div>
        )
    }
}
const mapStateToProps = state => {
    console.log("this is in map "+ state.loginReducer);
    return {
        login: state.loginReducer
    }
}

const mapDispatchToProps = dispatch => {
    return {
        handleSubmit: (username, password) => dispatch(actions.loginSubmit(username, password))
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Login)