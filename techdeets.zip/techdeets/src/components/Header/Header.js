import React from 'react';

const header = (props) => {
    return(
        <div>
            Header
        </div>
    )
}

export default header;