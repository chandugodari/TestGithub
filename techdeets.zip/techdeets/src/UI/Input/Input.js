import React from 'react';

import { TextField, Grid, Button } from '@material-ui/core';

const input = ( props) => {
    let inputElement = null;
    const inputClasses = []
    if(props.invalid && props.shouldValidate && props.touched) {

    }
    switch( props.elementType) {
        case ('input') :
        inputElement = <TextField 
        // {...props.elementConfig}
        id = {props.id}
        value = {props.value}
        label = {props.label}
        type = {props.type} 
        variant = "outlined"
        margin ="normal"
        onChange={props.changed} />;
        break;

        // default:
        // inputElement = <TextField 
        // {...props.elementConfig}
        // value={props.value}
        // onChange={props.changed}
        // />;

    }
    return(
        <div>
            {inputElement}
        </div>
    );


}
export default input;