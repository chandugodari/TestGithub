import * as actionTypes from './actionTypes'
import axios from 'axios'

export const loginSubmit = (username, password) => {
    return dispatch => {
      axios.get('https://jsonplaceholder.typicode.com/postsss')
      .then(response => {
        dispatch(loginStatus(true))
      })
      .catch((error) => {
        dispatch(loginStatus(false));
      })
    };
}
export const loginStatus = (loginStatus) => {
   return {
     type: actionTypes.LOGIN_STATUS,
     loginStatus
   }
}