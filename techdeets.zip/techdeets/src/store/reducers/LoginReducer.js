import * as actionTypes from '../actions/actionTypes';

const  loginReducer = (state = false, action) => {
    switch(action.type) {
        case actionTypes.LOGIN_STATUS:
            return action.loginStatus            
        default:
            return state

            
    }
};
export default loginReducer